from django.urls import path
from . import views


urlpatterns = [
    path('', views.index),
    path('about_us', views.about_us),
    path('menu', views.menu),
    path('reservation', views.reservation),
    path('make_res', views.make_res),
    path('contact_us', views.contact_us),
    path('create', views.create),
    path('success', views.success),
    path('update', views.update),
    path('delete/<int:res_id>', views.delete),
    path('login', views.login),
    path('logout', views.logout),
]