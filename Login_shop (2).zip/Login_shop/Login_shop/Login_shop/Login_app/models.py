from django.db import models
import re, bcrypt

# Create your models here.
class UserManager(models.Manager):
    def basic_validator(self, postData):
        errors = {}

        email_regex=re.compile(r'^[a-zA-Z0-9.+_-]+@[a-zA-Z0-9._-]+\.[a-zA-Z]+$')
        if len(postData['first_name']) < 2:
            errors['first_name'] = "First name should be at least 2 characters"

        if len(postData['last_name']) < 2:
            errors['last_name'] = "Last name should be at least 2 characters"

        if not email_regex.match(postData['email']):
            errors['email']= "Email must be valid"

        if len(postData['password']) < 8:
            errors['password'] = "Password should be at least 8 characters"

        if  postData['password'] != postData['confrim_password']:
            errors['confrim_password']="Password and Confirm Password must match"

        return errors
    
    
    def login_validator(self, postData):
        errors = {}

        user_query=User.objects.filter(email=postData['email'])
        if user_query== []:
            errors['email']=" E-mail must be valid"
        
        else:
            user = user_query[0] 

        if not bcrypt.checkpw(postData['password'].encode(), user.password.encode()):
            errors['password']="Password is wrong"

        return errors
        
class User(models.Model):
    first_name = models.CharField(max_length=255)
    last_name = models.CharField(max_length=255)
    email = models.EmailField(max_length=255)
    password = models.CharField(max_length=255)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    objects=UserManager()

class Reservation(models.Model):
    user_name = models.CharField(max_length=255)
    user_phone = models.CharField(max_length=255)
    user_email = models.EmailField(max_length=255)
    date = models.DateField(auto_now=True)
    time = models.TimeField(auto_now=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
