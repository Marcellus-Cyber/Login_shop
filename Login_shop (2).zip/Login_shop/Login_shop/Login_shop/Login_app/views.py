from urllib import request
from django.contrib.messages.api import error
from django.contrib import messages
from django.db.models.expressions import Value
from django.shortcuts import redirect, render
from .models import *
import bcrypt

# Create your views here.

def index(request):

    return render(request, "index.html")

def about_us(request):
    user=User.objects.get(id=request.session['user_id'])
    context = {
        'user':user,
        
    }
    return render(request, "about_us.html", context)

def menu(request):
    user=User.objects.get(id=request.session['user_id'])
    context = {
        'user':user,
        
        
    }
    return render(request, "menu.html", context)

def reservation(request):
    user=User.objects.get(id=request.session['user_id'])
    context = {
        'user':user,
        'res':Reservation.objects.last()
        
    }
    return render(request, "reservation.html", context)

def make_res(request):
    print(request.POST)
    user = User.objects.get(id=request.session["user_id"])
    res = Reservation.objects.create(
            user_name = request.POST['user_name'],
            user_phone = request.POST['user_phone'],
            user_email = request.POST['user_email'],
            date = request.POST['date'],
            time = request.POST['time'],
    )
    return redirect('/reservation')

def contact_us(request):
    user=User.objects.get(id=request.session['user_id'])
    context = {
        'user':user,
        
    }
    return render(request, "contact_us.html",context)

def create(request):
    errors=User.objects.basic_validator(request.POST)

    if len(errors) > 0:
        for key, value in errors.items():
            messages.error(request, value)
                
        return redirect('/')
    
    pw_hash = bcrypt.hashpw(request.POST['password'].encode(), bcrypt.gensalt()).decode()
    user=User.objects.create(
        first_name=request.POST['first_name'],
        last_name=request.POST['last_name'],
        email=request.POST['email'],
        password=pw_hash,
         )

    request.session['user_id']=user.id
    return redirect('/success')

def success(request):

    if 'user_id' not in request.session:
        messages.error(request, 'You must be logged in to see this site')
        return redirect('/')
    user=User.objects.get(id=request.session['user_id'])
    context ={
        'user':user
    }
    return render(request, "success.html", context)

def login (request):
    errors=User.objects.login_validator(request.POST)

    if len(errors) > 0:
        for key, value in errors.items():
            messages.error(request, value)
                
        return redirect('/')
    user = User.objects.filter(email=request.POST['email'])
    request.session['userid'] = user[0].id
        

    return redirect("/success")        

def logout(request):
    request.session.flush()
    return redirect('/')

def update(request):
    res = Reservation.objects.get(last)
    user_name = request.POST['user_name'],
    user_phone = request.POST['user_phone'],
    user_email = request.POST['user_email'],
    date = request.POST['date'],
    time = request.POST['time'],
    res.save()
    
    
    return redirect('reservation')

def delete(request, res_id):
    res = Reservation.objects.get(id=res_id)
    res.delete()

    return redirect('/reservation')